# General Rules & Regulations (Unified)

> This consolidated policy merges **General Rules & Regulations** and **General Terms & Conditions**, and incorporates relevant provisions from the **Parent & Guardian Release and Waiver of Liability**.

---

## 1. Admission & Waiver
- Entry requires a valid **waiver** signed by an adult (18+).
- By entering, guests acknowledge they have read and will follow these rules and any attraction‑specific instructions posted nearby.
- Guests must follow staff instructions at all times; failure to comply may result in removal without refund.

## 2. Age & Supervision
- Designed for **children 0–12 years**, but the venue has **no strict age limits** unless stated for a specific attraction.
- **Children under 6 years:** direct adult supervision required **in play areas**.
- **Children 6–12 years:** must be accompanied by an adult **on the premises**.

## 3. Safety & Conduct
### 3.1 Attire & Personal Items
- **Socks are mandatory** in play zones.
- **Long‑haired guests must tie up hair** to avoid accidents.
- **Remove** jewelry, glasses, scarves, and other loose items before playing; empty pockets.
- **Comfortable athletic clothing** is recommended.

### 3.2 Use of Equipment
- **Use equipment according to your skill level.** Do not attempt activities beyond your capabilities.
- Adhere to all posted signs and staff guidance.

### 3.3 Prohibited Behavior
- **No rough play**, pushing, wrestling, or horseplay.
- **No climbing** on nets, walls, fences, or any non‑designated surfaces.
- **No equipment misuse** or tampering.
- Disruptive behavior (e.g., aggression, foul language, harassment) may result in **expulsion**.

### 3.4 Health Restrictions
- Participation involves **inherent risks**. Guests with medical conditions (e.g., heart issues, injuries) **participate at their own risk**.
- **Pregnant guests** and guests with **respiratory problems** are **advised not to participate** in physical activities.
- Guests (and minors under their care) **must not participate under the influence of alcohol or drugs**.
- It is advisable to **consult a physician** before undertaking physical activity.

## 4. Attraction‑Specific Restrictions
- Some attractions have additional **age, height, or weight** restrictions. Follow posted signage and staff instructions.
- Restrictions will be displayed using the unified format for height, age and weight.

## 5. Technology‑Specific Rules (Phygital & Mixed Reality Zones)
- **No‑touch policy** for all digital and interactive hardware:
  - Do not touch, move, unplug, or otherwise tamper with projectors, tablets, or other equipment.
  - Do not throw objects at or touch projection surfaces/screens.
  - Parents/guardians are financially responsible for any damage to equipment caused by children in their care.
- **Device‑free play encouraged**: Personal phones/tablets are allowed but must not disrupt group activities or interactive experiences.

## 6. Tickets, Arrival & Wristbands
- Tickets are **non‑transferable** and **non‑refundable**.
- **No extensions** for late arrivals.
- Guests must wear the **correct wristband** (if provided) at all times in activity areas.

## 7. Food & Beverages
- **No outside food or drinks** inside the venue.
- Food and beverages may be consumed **only in designated dining areas**.
- **No food or drinks** are permitted in activity areas.

## 8. Personal Belongings & Lost Property
- The venue is **not responsible** for lost, stolen, or damaged items.
- **Lockers** may be available for storage.
- Items found are held for **30 days** and may then be transferred to **mall security**.
- Items dropped in foam pits or similar attractions are retrieved **during scheduled cleaning** only.

## 9. Accessibility
- **Partial wheelchair access** (varies by location). Some activities are **not recommended** for guests with mobility challenges.

## 10. Media & Privacy
- The venue may **capture photos/videos** for promotional purposes; **opt‑out** is available—please inform staff on arrival.
- By entering, you consent to the **collection and use of personal data** in accordance with our **privacy policy**. Personal data may be used for legitimate commercial purposes and **will not be disclosed to third parties** without lawful basis.

## 11. Emergency & First Aid
- Follow staff instructions during emergencies.
- **First aid stations** are staffed by trained personnel.
- In case of emergency, staff are authorized to **provide necessary first aid** and **seek medical attention** at the guest’s expense.
- **CCTV** operates throughout the facility for safety and security.

## 12. Operating Hours & Prices
- Operating hours and prices may change **without prior notice**.

## 13. Management Rights & Compliance
- Management reserves the right to **refuse entry** or **remove guests** for safety or behavioral concerns, without refund.
- The venue is **not liable** for injuries resulting from a guest’s failure to follow rules, posted instructions, or staff directions.
- Parents/guardians are **financially liable** for property damage caused by children in their care.

## 14. Universal Prohibitions
- **No pets** (except approved service animals with prior notice).
- **No weapons, sharp or hazardous items**.
- **No smoking or vaping** in play areas or other prohibited zones.

## 15. Additional Conditions
- Other terms and conditions may apply as necessary. Any attraction‑specific signage supplements these rules.

