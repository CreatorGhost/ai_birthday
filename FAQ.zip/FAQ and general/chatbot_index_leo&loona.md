# Chatbot Knowledge Base Index — Leo & Loona

---

## 1. general\_rules\_regulations

**Description:** Consolidated document of rules and regulations for Leo & Loona parks. Includes attire requirements, behavior guidelines, age and height restrictions, safety measures, equipment use, health advisories, food & beverage policy, personal belongings, media/privacy, and special rules for phygital/mixed reality zones.
**Tags:** park rules, safety, age restrictions, height restrictions, attire, behavior, food and drinks, personal belongings, media, phygital, mixed reality, medical restrictions, admission

---

## 2. discounts.md

**Description:** Discount policy for all Leo & Loona parks (LL\_Dalma, LL\_Yas, LL\_Festival). Details conditions for discounts for children of certain ages, People of Determination, and FAZAA, ADIB, HSBC cardholders. Specifies required documentation.
**Tags:** discounts, LL\_Dalma, LL\_Yas, LL\_Festival, Unlimited Day Pass, FAZAA, ADIB, HSBC, children, People of Determination (POD), conditions, documents

---

## 3. parks pricing (Google Sheets)

**Description:** Pricing table for tickets, packages, and services for each Leo & Loona park. Format: Google Sheets.
**Tags:** pricing, tickets, packages, services, LL\_Dalma, LL\_Yas, LL\_Festival

---

## 4. contacts (Google Sheets)

**Description:** Contact details for all Leo & Loona parks, including phone numbers, email addresses, media, and sites. **Tags:** contacts, phone, email, social media, LL\_Dalma, LL\_Yas, LL\_Festival

---

## 5. locations (Google Sheets)

**Description:** Addresses for all Leo & Loona parks. **Tags:** addresses, locations, LL\_Dalma, LL\_Yas, LL\_Festival

---

---

**Note:**

- **LL** = Leo & Loona park.
- **LL\_Festival** may also be referred to as LL\_Dubai, DFCM (Dubai Festival City Mall), or Festival.

