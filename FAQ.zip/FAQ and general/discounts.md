# Discounts

---

## LL_Festival Discounts
- 15% off on the **Unlimited Day Pass** for **FAZAA**, **ADIB**, and **HSBC** cardholders. The card must be presented at the reception and must be under the guest’s name. *Not applicable during public holidays.*  
- 50% off on the **Unlimited Day Pass** for:  
  • Children under 2 years old (with valid proof of age)  
  • People of Determination (with valid ID)  
- Adults enter free of charge.

---

## LL_Yas Discounts
- 50% off on the **Unlimited Day Pass** for:  
  • Children under 1 year old (with valid proof of age)  
  • People of Determination (with valid ID)  
- Adults enter free of charge.

---

## LL_Dalma Discounts
- 50% off on the **Unlimited Day Pass** for:  
  • Children aged 1 year and below (with valid proof of age)  
  • People of Determination (with valid ID)  
- Adults enter free of charge.
