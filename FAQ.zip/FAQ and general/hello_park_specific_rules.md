# Hello Park — Specific Information

---

## 1. Discounts for Hello Park

- Children under 2 years old: 50% off on Unlimited Day Pass (valid ID required).
- People of Determination: 50% off on Unlimited Day Pass (valid ID required).
- Adults: Free entry.
- FAZAA, ADIB, HSBC cardholders: 15% off on Unlimited Day Pass. *Note:* FAZAA/ADIB/HSBC discounts not applicable during public holidays.

## 2. Pricing for Hello Park

- 2-Hour Pass: 149 AED (Weekdays) / 169 AED (Weekends)
- Unlimited Day Pass: 179 AED (Weekdays) / 229 AED (Weekends)

## 3. Contacts for Hello Park

- **Landline:** +971 04 321 3393
- **WhatsApp:** +971 54 755 3467
- **Email:** [hello@hello-park.io](mailto\:hello@hello-park.io)
- **Website:** [https://hellokids.ae/](https://hellokids.ae/)

## 4. Location of Hello Park

- Dubai Festival City Mall – 1st floor, next to Bounce-X, South Entrance

